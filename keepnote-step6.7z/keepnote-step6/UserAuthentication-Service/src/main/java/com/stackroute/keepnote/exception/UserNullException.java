package com.stackroute.keepnote.exception;

public class UserNullException extends Exception {

    public UserNullException(String message) {
        super(message);
    }
}
